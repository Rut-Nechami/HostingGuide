import React from 'react';

const UpdateDate=()=>{
  return(
      <div>
          Im in updateDate!!!!!
      </div>
  )
}
export default UpdateDate;
