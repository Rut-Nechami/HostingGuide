import React from 'react';


const Details=(props)=>{
    return(
        <div>
    I'm in details!!!!
        </div>
    )
}
export default Details;
