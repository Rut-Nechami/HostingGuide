import React from 'react';
import Details from './details'

const NewHost=()=>{

    return (
        <div>
<Details/>
        </div>
    )

}
export default NewHost;