import React, { useState } from 'react';
import { TextField, Button } from '@material-ui/core';
import MoreDetails from './more_details';
import { useHistory } from 'react-router-dom';

const Details = () => {
    const [show, setShow] = useState(false);
    const [hostName, setHostName] = useState('');
    const [phone_Number, setPhone_Number] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const history = useHistory();
    function showMore() {
        setShow(!show);
        setHostName(this.refs.HostName.getValue());
        setPhone_Number(this.refs.Phone_Number.getValue());
        setAddress(this.refs.Address.getValue());
        setCity(this.refs.City.getValue());
    }
    function Register() {
        console.log("Register");
        // fetch(`http://localhost:3001/signIn?name=${userName}?password=${password}`)
        //     .then((res) => res.json())
        //     .then((data) => console.log(data))
        //     .catch((err) => {
        //         console.log("error", err);
        //     });
        history.push("/EndRegisterHost");
    }
    return (
        <div>Basic Details<br />
            <TextField id="outlined-basic" refs="HostName:" variant="outlined" /><br />
            <TextField id="outlined-basic" refs="Phone_Number:" variant="outlined" /><br />
            <TextField id="outlined-basic" refs="Address:" variant="outlined" /><br />
            <TextField id="outlined-basic" refs="City:" variant="outlined" /><br />
            <div></div>
            <Button variant="contained" color="primary" onClick={showMore}>We want to get to know you better</Button>
            {show ? <MoreDetails/> : null}
            {/* hostName={hostName} phone_Number={phone_Number} address={address} city={city} */}
            <br></br>
            {show ? <Button variant="contained" color="red" onClick={Register}>WE'RE JOINING TOO😍😍😍</Button> : null}
        </div>
    )

}
export default Details;