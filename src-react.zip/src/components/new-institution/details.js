import React from 'react';
import { TextField, Button } from '@material-ui/core';
import { useHistory } from 'react-router-dom';

const Details = () => {

    const history = useHistory();
    function Register() {
        console.log("Register");
        history.push("/EndRegisterIs");
    }
    return (
        <div>
            Basic Details
            <br />
            <TextField id="outlined-basic" label="InstitutionName:" variant="outlined" /><br />
            <TextField id="outlined-basic" label="Phone Number:" variant="outlined" /><br />
            <TextField id="outlined-basic" label="Address:" variant="outlined" /><br />
            <TextField id="outlined-basic" label="City:" variant="outlined" /><br />
            <TextField id="outlined-basic" label="Number Of Students:" variant="outlined" /><br /><br />
            <Button variant="contained" color="red" onClick={Register}>WE'RE JOINING TOO😍😍😍</Button>
        </div>
    )
}

export default Details;