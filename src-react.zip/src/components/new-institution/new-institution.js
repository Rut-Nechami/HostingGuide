import React from 'react';
import Details from './details';

const NewInstitution=()=>{
    return(
<div>
  <Details/>
</div>
    )
}

export default NewInstitution;