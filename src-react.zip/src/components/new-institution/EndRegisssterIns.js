import React from 'react';
import { Button } from '@material-ui/core';

const EndRegister = () => {
    return (
        <div>
            <div>
                WELCOME INSTITUSION!!!!!
        </div>
            <Button variant="contained">To the List of Hosts</Button>
        </div>
    )
}
export default EndRegister;