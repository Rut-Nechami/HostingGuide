import React from 'react';

const Institutions = () => {
    return (
        <div>
            Welcome Institution!
        </div>
    )
}
export default Institutions;